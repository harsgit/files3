package com.book.exception;

public class BookException  extends Exception{
	
		public BookException(String name)
		{
			super(name);
		}

}
