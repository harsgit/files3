package lab2;

public class Positive {
public static void main(String[] args) {
	
	int num1=Integer.valueOf(args[0]);
	if(num1>0)
	{
		System.out.println("Positive Number");
	}
	else
	{
		System.out.println("Negative Number");
	}
	
}
}
