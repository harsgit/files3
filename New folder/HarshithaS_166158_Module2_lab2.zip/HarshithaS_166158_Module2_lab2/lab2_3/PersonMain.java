package lab2_3;

public class PersonMain {
	public static void main(String[] args) {
		Person p = new Person();
		

		
	} 
	}


