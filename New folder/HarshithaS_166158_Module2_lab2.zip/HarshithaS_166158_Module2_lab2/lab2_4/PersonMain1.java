package lab2_4;

public class PersonMain1 {
	public static void main(String[] args) {
		
			Person1 p = new Person1();
		p.getPhoneNumber(123456789);
		p.Display();
	}

}
