package lab2_5;

public enum EnumGender {
	M,F;

}
