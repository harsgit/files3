package lab2_5;



public class PersonMain {
	public static void main(String[] args) {
		
			Person p = new Person();
			p.getPhoneNumber(123456789);
		p.Display();
		System.out.println("Gender :"+" "+EnumGender.F);
		
	}

}

