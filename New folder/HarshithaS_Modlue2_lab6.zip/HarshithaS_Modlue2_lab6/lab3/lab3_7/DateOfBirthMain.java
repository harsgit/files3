package lab3_7;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DateOfBirthMain
{
   public static void main(String[] args)
   { DateOfBirth  d=new DateOfBirth();
	   d.calcAge();
	   
   }
}
