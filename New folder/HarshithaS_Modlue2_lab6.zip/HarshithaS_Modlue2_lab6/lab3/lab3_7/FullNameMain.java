package lab3_7;

public class FullNameMain {
	
	    
	    public static void main(String args[])
	{
	FullName f = new FullName();
	f.fullName();

	}
	    
	  
	}

