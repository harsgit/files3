
public class AccountAbstractExtend extends Account {

	@Override
	public void withdraw(double amount) {
		
			 balance-=amount;
			 //System.out.println();
		 
		  
		
	}

}
