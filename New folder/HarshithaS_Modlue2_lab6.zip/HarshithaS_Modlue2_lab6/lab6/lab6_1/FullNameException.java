package lab6_1;

public class FullNameException extends Exception {
	
		String name;

public FullNameException(String name) {
			super();
			this.name = name;
		}

		
		

		

		

	}


