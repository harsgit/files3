package lab6_2;

public class AgeException  extends Exception
{
	String name;

	public AgeException(String name) {
		super();
		this.name = name;
	}

	

}
