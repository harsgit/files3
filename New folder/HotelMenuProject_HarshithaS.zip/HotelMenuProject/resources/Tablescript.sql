Create table HotelMenu(DISH_NAME                                          VARCHAR2(20),DISH_PRICE                                      NUMBER(20));

Create Table Customer(CUST_ID VARCHAR2(4),CUST_NAME  VARCHAR2(20), CUST_PHNO                                          VARCHAR2(10));

CREATE SEQUENCE cust_Id
START WITH 100;
