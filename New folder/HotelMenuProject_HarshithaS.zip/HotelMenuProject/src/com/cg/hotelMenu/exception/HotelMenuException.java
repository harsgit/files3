package com.cg.hotelMenu.exception;

public class HotelMenuException extends Exception {

	public HotelMenuException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
